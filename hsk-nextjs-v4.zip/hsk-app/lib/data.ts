import sectionsData from "@/data/sections.json";
import hskData from "@/data/hsk-levels.json";
import classifiersData from "@/data/classifiers.json";
import navData from "@/data/nav.json";
import type {
  Section,
  HskSystem,
  Classifier,
  NavItem,
} from "@/lib/types";

export function getSections(): Section[] {
  return sectionsData.sections as Section[];
}

export function getHskSystems(): Record<string, HskSystem> {
  return hskData.systems as Record<string, HskSystem>;
}

export function getHskSystem(id: "2" | "3"): HskSystem | null {
  const sys = (hskData.systems as Record<string, HskSystem>)[id];
  return sys ?? null;
}

export function getClassifiers(): Classifier[] {
  return classifiersData.classifiers as Classifier[];
}

export function getNavItems(): NavItem[] {
  return navData.items as NavItem[];
}
