import { Hero } from "@/components/Hero";

export default function ProgressPage() {
  return (
    <main className="min-h-screen">
      <Hero
        title="تقدمي"
        subtitle="تتبّع رحلتك في تعلُّم اللغة الصينية"
        emoji="📊"
        kicker="进度 · التقدم"
      />
      <div className="mx-auto max-w-2xl px-4 sm:px-5">
        <div className="rounded-3xl border border-dashed border-[#E0E0E0] bg-[#FAFAFA] p-10 text-center">
          <div className="mb-3 text-4xl">🚧</div>
          <h2 className="mb-2 text-lg font-extrabold text-ink">قريباً</h2>
          <p className="text-sm leading-relaxed text-muted">
            هنا ستظهر إحصاءات الكلمات التي راجعتها، عدد البطاقات اليومية،
            وسلسلة الأيام المتتالية.
          </p>
        </div>
      </div>
    </main>
  );
}
