import { Hero } from "@/components/Hero";
import { HskLevelCard } from "@/components/HskLevelCard";
import { getHskSystem, getHskSystems } from "@/lib/data";
import Link from "next/link";
import { cn } from "@/lib/utils";

export default function HskLevelsPage({
  searchParams,
}: {
  searchParams: { system?: string; level?: string };
}) {
  const systems = getHskSystems();
  const sysId = (searchParams.system === "3" ? "3" : "2") as "2" | "3";
  const sys = getHskSystem(sysId)!;
  const total = sys.levels.reduce((s, l) => s + l.count, 0);

  // أيّ مستوى محدد للتمييز
  const focusedLevel = searchParams.level?.trim() || null;

  return (
    <main className="min-h-screen">
      <Hero
        title="مستويات HSK"
        subtitle={`${sys.name} — ${sys.subtitle}`}
        emoji={sysId === "2" ? "旧" : "新"}
        kicker={`${total.toLocaleString("en-US")} كلمة · ${sys.levels.length} مستويات`}
      />

      <div className="mx-auto mb-5 max-w-2xl px-4 sm:px-5">
        <div className="grid grid-cols-2 gap-2 rounded-2xl bg-[#F7F7F7] p-1.5">
          {(["2", "3"] as const).map((id) => {
            const s = systems[id];
            const active = id === sysId;
            return (
              <Link
                key={id}
                href={`/hsk-levels?system=${id}`}
                className={cn(
                  "flex flex-col items-center rounded-xl py-2.5 transition-colors",
                  active ? "bg-white shadow-card" : "hover:bg-white/50"
                )}
              >
                <span
                  className={cn(
                    "text-sm font-bold",
                    active ? "text-ink" : "text-muted"
                  )}
                >
                  {s.name}
                </span>
                <span className="text-[11px] text-muted">{s.subtitle}</span>
              </Link>
            );
          })}
        </div>
      </div>

      <section className="mx-auto flex max-w-2xl flex-col gap-3.5 px-4 sm:px-5">
        {sys.levels.map((lv) => {
          // التمييز: مطابقة على label بدون "HSK "، أو على id
          const labelKey = lv.label.replace(/^HSK\s*/, "").trim();
          const isFocused =
            focusedLevel === labelKey ||
            focusedLevel === lv.id ||
            focusedLevel === lv.label;
          return (
            <div
              key={lv.id}
              className={cn(
                "rounded-3xl transition-all",
                isFocused && "ring-2 ring-offset-2",
              )}
              style={isFocused ? { boxShadow: `0 0 0 3px ${lv.color}33` } : undefined}
            >
              <HskLevelCard level={lv} />
            </div>
          );
        })}
      </section>
    </main>
  );
}
