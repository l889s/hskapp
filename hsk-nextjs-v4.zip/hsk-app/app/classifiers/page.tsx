import { Suspense } from "react";
import { Hero } from "@/components/Hero";
import { ClassifiersClient } from "@/components/ClassifiersClient";
import { getClassifiers } from "@/lib/data";

export default function ClassifiersPage() {
  const items = getClassifiers();
  return (
    <main className="min-h-screen">
      <Hero
        title="كلمات الكمية"
        subtitle={`${items.length} مصنِّف · الاستخدام وملاحظات المعلم`}
        emoji="量"
        kicker="量词用法 · 量词"
      />
      <Suspense fallback={<div className="mx-auto max-w-2xl px-5 text-muted">جاري التحميل...</div>}>
        <ClassifiersClient items={items} />
      </Suspense>
    </main>
  );
}
