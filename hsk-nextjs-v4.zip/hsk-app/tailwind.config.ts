import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        coral:  { DEFAULT: "#FF4D4F", soft: "#FFF1F0" },
        violet: { DEFAULT: "#7C5CFC", soft: "#F2EEFF" },
        mint:   { DEFAULT: "#11A88E", soft: "#E6F7F3" },
        ink: "#1A1A1A",
        muted: "#8C8C8C",
      },
      fontFamily: {
        sans: ["'IBM Plex Sans Arabic'", "'Noto Sans SC'", "sans-serif"],
        cn:   ["'Noto Sans SC'", "sans-serif"],
      },
      boxShadow: {
        card:      "0 2px 16px rgba(0,0,0,0.05)",
        cardHover: "0 4px 24px rgba(0,0,0,0.08)",
        coral:     "0 6px 18px rgba(255,77,79,0.32)",
        nav:       "0 -2px 16px rgba(0,0,0,0.06)",
      },
    },
  },
  plugins: [],
};
export default config;
