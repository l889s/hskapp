"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Layers, Sparkles, TrendingUp, LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import type { NavItem } from "@/lib/types";

const ICONS: Record<NavItem["icon"], LucideIcon> = {
  Home,
  Layers,
  Sparkles,
  TrendingUp,
};

export function BottomNav({ items }: { items: NavItem[] }) {
  const pathname = usePathname();

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-50 mx-auto max-w-2xl border-t border-[#F0F0F0] bg-white/95 backdrop-blur shadow-nav"
      aria-label="التنقل الرئيسي"
    >
      <ul className="grid grid-cols-4">
        {items.map((it) => {
          const Icon = ICONS[it.icon];
          const isActive =
            it.href === "/"
              ? pathname === "/"
              : pathname.startsWith(it.href);
          return (
            <li key={it.href}>
              <Link
                href={it.href}
                className={cn(
                  "flex flex-col items-center gap-1 py-3 text-[11px] font-semibold transition-colors",
                  isActive ? "text-coral" : "text-muted hover:text-ink"
                )}
              >
                <Icon
                  className={cn(
                    "h-5 w-5",
                    isActive ? "stroke-[2.5]" : "stroke-2"
                  )}
                />
                <span>{it.label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
