"use client";

import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Search, X, Heart, Sparkles, Volume2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useFavorites } from "@/lib/storage";
import { useToast } from "@/components/Toast";
import { useSpeech } from "@/lib/useSpeech";
import { ClassifierFlashcards } from "@/components/ClassifierFlashcards";
import type { Classifier } from "@/lib/types";

const HSK_LEVELS = [1, 2, 3, 4, 5, 6] as const;

export function ClassifiersClient({ items }: { items: Classifier[] }) {
  const searchParams = useSearchParams();
  const initialHsk = (() => {
    const raw = searchParams.get("hsk");
    if (!raw) return null;
    const n = parseInt(raw, 10);
    return Number.isFinite(n) && n >= 1 && n <= 6 ? n : null;
  })();

  const [query, setQuery] = useState("");
  const [hsk, setHsk] = useState<number | null>(initialHsk);
  const [onlyFavs, setOnlyFavs] = useState(false);
  const [practiceOpen, setPracticeOpen] = useState(false);

  const { has, toggle, count } = useFavorites();
  const { toast } = useToast();
  const { speak, supported } = useSpeech();

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return items.filter((c) => {
      if (hsk !== null && c.hsk !== hsk) return false;
      if (onlyFavs && !has(c.id)) return false;
      if (!q) return true;
      return (
        c.char.includes(q) ||
        c.pinyin.toLowerCase().includes(q) ||
        c.ar.includes(q) ||
        c.usage.includes(q) ||
        c.examples.some((e) => e.zh.includes(q) || e.ar.includes(q))
      );
    });
  }, [items, query, hsk, onlyFavs, has]);

  function onToggleFav(c: Classifier) {
    const wasFav = has(c.id);
    toggle(c.id);
    toast(
      wasFav ? `أُزيل "${c.char}" من المفضلة` : `تمت إضافة "${c.char}" للمفضلة`,
      wasFav ? "info" : "success"
    );
  }

  function startPractice() {
    if (filtered.length === 0) {
      toast("لا توجد مصنِّفات للتدريب — عدّل الفلاتر", "error");
      return;
    }
    setPracticeOpen(true);
  }

  function onSpeak(text: string) {
    if (!supported) {
      toast("متصفّحك لا يدعم النطق التلقائي", "error");
      return;
    }
    speak(text);
  }

  return (
    <>
      {practiceOpen && (
        <ClassifierFlashcards
          items={filtered}
          onClose={() => setPracticeOpen(false)}
        />
      )}

      <div className="mx-auto max-w-2xl px-4 sm:px-5">
        <div className="relative mb-4">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث: 个 / gè / عام / للأشياء / 一个人..."
            dir="rtl"
            className={cn(
              "w-full rounded-2xl border bg-white px-12 py-3.5 text-[15px] outline-none transition-colors",
              query ? "border-violet" : "border-[#E8E8E8]"
            )}
          />
          <Search className="absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-[#B0B0B0]" />
          {query && (
            <button
              type="button"
              onClick={() => setQuery("")}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-[#B0B0B0]"
              aria-label="مسح"
            >
              <X className="h-5 w-5" />
            </button>
          )}
        </div>

        <div className="mb-3">
          <div className="mb-1.5 text-[11px] font-bold text-muted">المستوى</div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setHsk(null)}
              className={cn(
                "rounded-xl px-3.5 py-1.5 text-xs font-bold transition-colors",
                hsk === null
                  ? "bg-violet text-white"
                  : "bg-[#F7F7F7] text-muted hover:bg-[#EEEEEE]"
              )}
            >
              الكل
            </button>
            {HSK_LEVELS.map((lv) => (
              <button
                key={lv}
                onClick={() => setHsk(lv)}
                className={cn(
                  "rounded-xl px-3.5 py-1.5 text-xs font-bold transition-colors",
                  hsk === lv
                    ? "bg-violet text-white"
                    : "bg-[#F7F7F7] text-muted hover:bg-[#EEEEEE]"
                )}
              >
                HSK {lv}
              </button>
            ))}
          </div>
        </div>

        <div className="mb-4 flex flex-wrap items-center gap-2">
          <button
            onClick={() => setOnlyFavs((v) => !v)}
            className={cn(
              "flex items-center gap-1.5 rounded-xl px-3.5 py-1.5 text-xs font-bold transition-colors",
              onlyFavs
                ? "bg-coral text-white"
                : "bg-[#F7F7F7] text-muted hover:bg-[#EEEEEE]"
            )}
          >
            <Heart className={cn("h-3.5 w-3.5", onlyFavs && "fill-current")} />
            المفضلة {count > 0 && `(${count})`}
          </button>

          <button
            onClick={startPractice}
            className="ms-auto flex items-center gap-1.5 rounded-xl bg-ink px-4 py-2 text-xs font-bold text-white hover:bg-black"
          >
            <Sparkles className="h-3.5 w-3.5" />
            ابدأ التمرين
          </button>
        </div>

        <div className="mb-3 text-xs font-semibold text-muted">
          {filtered.length} مصنِّف
        </div>

        <div className="flex flex-col gap-3">
          {filtered.length === 0 && (
            <div className="rounded-2xl bg-[#F7F7F7] p-8 text-center text-sm text-muted">
              لا توجد نتائج
            </div>
          )}

          {filtered.map((c) => (
            <article
              key={c.id}
              className="rounded-3xl border border-[#F0F0F0] bg-white p-5 shadow-card"
            >
              <div className="flex items-start gap-4">
                <button
                  onClick={() => onSpeak(c.char)}
                  className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-violet-soft transition-transform hover:scale-105"
                  aria-label={`نطق ${c.char}`}
                >
                  <span className="font-cn text-3xl font-bold text-violet">
                    {c.char}
                  </span>
                </button>

                <div className="min-w-0 flex-1">
                  <div className="mb-1 flex flex-wrap items-center gap-2">
                    <span className="text-[13px] italic text-muted" dir="ltr">
                      {c.pinyin}
                    </span>
                    <span className="rounded-md bg-violet-soft px-2 py-0.5 text-[10px] font-bold text-violet">
                      HSK {c.hsk}
                    </span>
                  </div>
                  <h3 className="mb-2 text-base font-extrabold text-ink">
                    {c.ar}
                  </h3>
                  <p className="text-[13px] leading-relaxed text-muted">
                    {c.usage}
                  </p>
                </div>

                <button
                  onClick={() => onToggleFav(c)}
                  className="shrink-0 rounded-xl p-1.5 transition-colors hover:bg-[#F7F7F7]"
                  aria-label="إضافة للمفضلة"
                >
                  <Heart
                    className={cn(
                      "h-5 w-5 transition-colors",
                      has(c.id) ? "fill-coral text-coral" : "text-[#C8C8C8]"
                    )}
                  />
                </button>
              </div>

              {c.examples.length > 0 && (
                <div className="mt-4 space-y-2">
                  {c.examples.map((ex, i) => (
                    <button
                      key={i}
                      onClick={() => onSpeak(ex.zh)}
                      className="flex w-full items-center gap-2 rounded-xl bg-violet-soft/40 px-3 py-2 text-right transition-colors hover:bg-violet-soft"
                    >
                      <Volume2 className="h-4 w-4 shrink-0 text-violet" />
                      <div className="flex-1">
                        <div dir="ltr" className="font-cn text-[15px] text-ink">
                          {ex.zh}
                        </div>
                        <div className="text-xs text-muted">{ex.ar}</div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </article>
          ))}
        </div>
      </div>
    </>
  );
}
