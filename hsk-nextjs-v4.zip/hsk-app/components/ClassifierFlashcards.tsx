"use client";

import { useEffect, useMemo, useState } from "react";
import {
  X,
  RotateCw,
  ArrowRight,
  ArrowLeft,
  Volume2,
  RefreshCw,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useSpeech } from "@/lib/useSpeech";
import { useToast } from "@/components/Toast";
import { useProgress } from "@/lib/storage";
import type { Classifier } from "@/lib/types";

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function ClassifierFlashcards({
  items,
  onClose,
}: {
  items: Classifier[];
  onClose: () => void;
}) {
  const [deck, setDeck] = useState<Classifier[]>(() => shuffle(items));
  const [idx, setIdx] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [seen, setSeen] = useState(1);

  const { speak } = useSpeech();
  const { toast } = useToast();
  const { bumpLevel } = useProgress();

  const card = deck[idx];
  const total = deck.length;
  const progress = useMemo(
    () => Math.round((seen / total) * 100),
    [seen, total]
  );

  // إغلاق بزر Esc
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
      if (e.key === " " || e.key === "Enter") {
        e.preventDefault();
        setFlipped((f) => !f);
      }
      if (e.key === "ArrowLeft") next();
      if (e.key === "ArrowRight") prev();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idx, total]);

  // عند الانتهاء من الجولة
  useEffect(() => {
    if (seen === total && total > 0) {
      bumpLevel("classifiers_practiced", total);
      toast(`أحسنت! أكملت ${total} مصنِّفاً 🎉`, "success");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seen, total]);

  function next() {
    setFlipped(false);
    setIdx((i) => {
      const ni = (i + 1) % total;
      setSeen((s) => Math.min(s + 1, total));
      return ni;
    });
  }

  function prev() {
    setFlipped(false);
    setIdx((i) => (i - 1 + total) % total);
  }

  function restart() {
    setDeck(shuffle(items));
    setIdx(0);
    setSeen(1);
    setFlipped(false);
    toast("تم خلط البطاقات من جديد", "info");
  }

  if (!card) return null;

  return (
    <div
      className="fixed inset-0 z-[80] flex flex-col bg-white"
      role="dialog"
      aria-modal="true"
      aria-label="وضع التمرين"
    >
      {/* الرأس */}
      <div className="flex items-center justify-between border-b border-[#F0F0F0] px-4 py-3">
        <button
          onClick={onClose}
          className="rounded-xl p-2 text-muted transition-colors hover:bg-[#F7F7F7]"
          aria-label="إغلاق"
        >
          <X className="h-5 w-5" />
        </button>
        <div className="text-sm font-bold text-ink">
          {idx + 1} / {total}
        </div>
        <button
          onClick={restart}
          className="rounded-xl p-2 text-muted transition-colors hover:bg-[#F7F7F7]"
          aria-label="إعادة الخلط"
        >
          <RefreshCw className="h-5 w-5" />
        </button>
      </div>

      {/* شريط التقدم */}
      <div className="h-1.5 bg-[#F0F0F0]">
        <div
          className="h-full bg-coral transition-all duration-300"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* المحتوى */}
      <div className="flex flex-1 flex-col items-center justify-center px-5 py-6">
        <div className="w-full max-w-md flip-scene">
          <div
            className={cn("flip-card h-[420px]", flipped && "flipped")}
            onClick={() => setFlipped((f) => !f)}
            role="button"
            tabIndex={0}
          >
            {/* الأمامي */}
            <div className="flip-face flex flex-col items-center justify-center rounded-3xl border border-[#F0F0F0] bg-white p-6 shadow-card text-center cursor-pointer">
              <div
                className="font-cn text-[120px] font-bold text-coral leading-none"
                dir="ltr"
              >
                {card.char}
              </div>
              <div className="mt-3 text-lg italic text-muted" dir="ltr">
                {card.pinyin}
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  speak(card.char);
                }}
                className="mt-6 flex items-center gap-2 rounded-xl bg-coral-soft px-4 py-2 text-sm font-bold text-coral"
              >
                <Volume2 className="h-4 w-4" />
                استمع للنطق
              </button>
              <div className="mt-6 text-xs font-semibold text-muted">
                اضغط البطاقة لقلبها
              </div>
            </div>

            {/* الخلفي */}
            <div className="flip-back flip-face flex flex-col rounded-3xl border border-[#F0F0F0] bg-white p-6 shadow-card cursor-pointer">
              <div className="mb-3 flex items-center justify-between">
                <span className="rounded-md bg-coral-soft px-2.5 py-0.5 text-[11px] font-bold text-coral">
                  HSK {card.hsk}
                </span>
                <span className="font-cn text-2xl text-muted" dir="ltr">
                  {card.char}
                </span>
              </div>
              <h3 className="mb-3 text-2xl font-extrabold text-ink">
                {card.ar}
              </h3>
              <p className="mb-4 text-sm leading-relaxed text-muted">
                {card.usage}
              </p>

              {card.examples.length > 0 && (
                <div className="space-y-2">
                  <div className="text-[11px] font-bold text-muted">
                    أمثلة:
                  </div>
                  {card.examples.slice(0, 2).map((ex, i) => (
                    <button
                      key={i}
                      onClick={(e) => {
                        e.stopPropagation();
                        speak(ex.zh);
                      }}
                      className="flex w-full items-center gap-2 rounded-xl bg-coral-soft/40 px-3 py-2 text-right hover:bg-coral-soft/70"
                    >
                      <Volume2 className="h-4 w-4 shrink-0 text-coral" />
                      <div className="flex-1">
                        <div
                          dir="ltr"
                          className="font-cn text-[15px] text-ink"
                        >
                          {ex.zh}
                        </div>
                        <div className="text-xs text-muted">{ex.ar}</div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* الأزرار */}
      <div className="border-t border-[#F0F0F0] p-4">
        <div className="mb-2 flex gap-2.5">
          <button
            onClick={() => setFlipped((f) => !f)}
            className={cn(
              "flex flex-1 items-center justify-center gap-2 rounded-2xl py-3.5 text-sm font-bold transition-colors",
              flipped
                ? "bg-[#F7F7F7] text-muted"
                : "bg-coral text-white shadow-coral"
            )}
          >
            <RotateCw className="h-4 w-4" />
            {flipped ? "إخفاء الإجابة" : "قلب البطاقة"}
          </button>
        </div>

        <div className="flex gap-2.5">
          <button
            onClick={prev}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-2xl bg-[#F7F7F7] py-3 text-sm font-bold text-muted hover:bg-[#EEEEEE]"
          >
            <ArrowRight className="h-4 w-4" />
            السابق
          </button>
          <button
            onClick={next}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-2xl bg-ink py-3 text-sm font-bold text-white hover:bg-black"
          >
            التالي
            <ArrowLeft className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
