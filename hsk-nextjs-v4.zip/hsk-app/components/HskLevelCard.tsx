import { ArrowLeft } from "lucide-react";
import type { HskLevel } from "@/lib/types";

export function HskLevelCard({ level }: { level: HskLevel }) {
  const { label, cn: cnLabel, emoji, color, soft, count, desc } = level;
  return (
    <div className="relative cursor-pointer rounded-3xl bg-white border border-[#F0F0F0] p-5 shadow-card transition-shadow hover:shadow-cardHover">
      <div className="flex items-start gap-4">
        <div
          className="shrink-0 flex h-14 w-14 items-center justify-center rounded-2xl text-3xl"
          style={{ background: soft }}
        >
          <span>{emoji}</span>
        </div>

        <div className="min-w-0 flex-1">
          <div className="mb-1 flex items-center gap-2">
            <span className="text-base font-extrabold text-ink">{label}</span>
            <span
              className="font-cn rounded-md px-2 py-0.5 text-[11px] font-semibold"
              style={{ background: soft, color }}
            >
              {cnLabel}
            </span>
          </div>
          <p className="text-[13px] text-muted leading-relaxed">{desc}</p>
        </div>

        <div className="shrink-0 text-left">
          <div className="text-base font-black leading-none" style={{ color }}>
            {count.toLocaleString("en-US")}
          </div>
          <div className="mt-1 text-[10px] text-[#B0B0B0]">كلمة</div>
        </div>
      </div>

      <div
        className="absolute bottom-4 left-4 flex h-8 w-8 items-center justify-center rounded-xl"
        style={{ background: soft, color }}
      >
        <ArrowLeft className="h-4 w-4" />
      </div>
    </div>
  );
}
